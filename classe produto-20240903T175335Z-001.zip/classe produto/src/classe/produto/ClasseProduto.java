/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classe.produto;

/**
 *
 * @author aluno.saolucas
 */
public class ClasseProduto {

   
    public static void main(String[] args) {
      produto p1 = new produto();
      produto p2 = new produto("Iphone 14",500, 8500);
   
        
        
         p1.exibirInfo();
            System.out.println("=================");
        p2.exibirInfo();
        
    }
    
}
