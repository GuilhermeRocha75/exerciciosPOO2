
package classe.produto;


public class produto {
    private String nome;
    private int quantidade;
    private int preco;
    
    //metodo contrutor sem parametro
    public produto (){
        nome = "Sem nome";
        quantidade = 0;
        preco = 0;
        
    }
    
    
     //metodo com parametros
    public produto(String nome, int quantidade,int preco){
        this.nome=nome;
        this.quantidade=quantidade;
        this.preco=preco;
      
    }
    
    
    
    
    
    
    
    //metodos acessores
     public String getNome(){
         return nome;
     }
     public void setNome(String nome){
        this.nome = nome;
    }
    
     
     public int getQuantidade(){
        return quantidade;  
    }
    public void setQuantidade(int quantidade){
        this.quantidade = quantidade;
    } 
   
    
       public int getPreco(){
        return preco;  
    }
    public void setPreco(int preco){
        this.preco = preco;
    }
    
    
    
     //Metodo para exibir informaçoes da pessoa
    public void exibirInfo(){
        System.out.println("Nome:"+nome);
        System.out.println("Quantidade:"+quantidade);
         System.out.println("Preço:"+ preco);
      
    }
    
    
}
